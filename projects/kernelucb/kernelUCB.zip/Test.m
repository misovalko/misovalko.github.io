global D;
global theta_star;
global Sigma;
global T;
global DK

%%%%%%%%%%%% Set Up %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K = 10; % Number of Feeds aka Arms
d = 5; % max number of features aka words
T = 200; % Time horizon
accur = 10;

% Define Problem Parameters
D = 2*(rand(K,d)-0.5);
theta_star = 2*(rand(d,1)-0.5);
%Sigma = zeros(K,1); %No Noise 
%Sigma = abs(rand(K,1)); %Noise
Sigma = ones(K,1);
type = 'rbf';

% Set Algorithm Parameters
lambda = [0.01, 0.033, 0.01, 0.33, 1, 3.3, 10,];
delta = 0.01;

%%%%%%%%%%%%% Run Tests %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Get Kernel Matrix
switch type
    case 'linear'
        DK = D*D';
    case 'rbf'
        DK = rbf(D,2);
    case'poly'
        break;
end

rewards = zeros(T,accur,7);

tic
for i = 1:accur
    for j = 1:7
        [rewards(:,i,j+1), ~] = KernelUCB( T, lambda(j), delta, K, type);
    end
    
    time = toc;
    clc;
    disp('Time remaining:')
    (accur*(time/i) - time)/60
    disp('Average time spent:')
    time/i
end
rewards = rewards;

regrets = zeros(accur,7,T);
for j = 1:7
    for i = 1:accur
        regrets(i,j,:) = Regret(rewards(:,i,j), type);
    end
end

%  expRegret = zeros(T,7)
%  for j = 1:7
%      for t = 1:T
%          expRegret(t,j) = sum(regrets(T,:,j))/accur;
%      end
%  end
% 
% varRegret = zeros(T,7)
% for j = 1:7
%     for t = 1:T
%         varRegret(t,j) = sum((regrets(T,:,j).- expRegret(t,j)).^2)
%     end
% end

hold on
boxplot(regrets(:,:,T))
hold off