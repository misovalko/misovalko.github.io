import random
import math

__author__ = 'jb-inira'


class Tree:
    def __init__(self, support, father, depth, rhos, bbox):
        self.noisyvalue = None
        self.evaluated = None
        self.meanvalue = None
        self.visited = [0] * len(rhos)
        self.rewards = [0.] * len(rhos)
        self.bvalue = [float("inf")] * len(rhos)
        self.uvalue = [float("inf")] * len(rhos)
        self.mbvalue = [-float("inf")] * len(rhos)
        self.muvalue = [-float("inf")] * len(rhos)
        self.bestempiricalnoised = -float("inf")
        self.bestempiricalmean = -float("inf")
        self.rhos = rhos
        self.depth = depth
        self.support = support
        self.father = father
        self.children = []
        self.BBox = bbox

    def add_children(self):
        child_supports = self.BBox.split(self.support)
        self.children = [Tree(s, self, self.depth+1, self.rhos, self.BBox) for s in child_supports]

    def explore(self, k):
        if self.visited[k] == 0:
            return self
        elif not self.children:
            self.add_children()
            return random.choice(self.children)
        else:
            return max(self.children, key=lambda x: x.bvalue[k]).explore(k)

    def explore_simple(self, k):
        if not self.children:
            return self
        else:
            return max(self.children, key=lambda x: x.mbvalue[k]).explore(k)

    # def get_simple(self, k):
    #     leaf = self.explore(k)
    #     x = leaf.BBox.rpoint(leaf.support)
    #     return self.BBox.fmax - self.BBox.f_mean(x)

    def update_node(self, alpha, nu, k):
        mean = float(self.rewards[k])/float(self.visited[k])
        ucb = math.sqrt(2.*alpha/float(self.visited[k]))
        metric = nu*math.pow(self.rhos[k], self.depth)
        self.uvalue[k] = mean + ucb + metric
        self.muvalue[k] = mean - ucb - metric

    def update_path(self, reward, alpha, nu, k):
        self.rewards[k] += reward
        self.visited[k] += 1
        self.update_node(alpha, nu, k)
        if not self.children:
            self.bvalue[k] = self.uvalue[k]
            self.mbvalue[k] = self.muvalue[k]
        else:
            self.bvalue[k] = min(self.uvalue[k], max([child.bvalue[k] for child in self.children]))
            self.mbvalue[k] = max(self.muvalue[k], max([child.mbvalue[k] for child in self.children]))
        if self.father is not None:
            self.father.update_path(reward, alpha, nu, k)

    def update_all(self, alpha, nu):
        for k in range(len(self.rhos)):
            self.update_node(alpha, nu, k)
        if not self.children:
            self.bvalue = self.uvalue
        else:
            for child in self.children:
                child.update_all(alpha, nu)
            for k in range(len(self.rhos)):
                self.bvalue = min(self.uvalue[k], max([child.bvalue[k] for child in self.children]))

    def sample(self, alpha, nu, k):
        leaf = self.explore(k)
        existed = False
        if leaf.noisyvalue is None:
            x = self.BBox.rpoint(leaf.support)  # self.BBox.center(leaf.support)t)
            leaf.evaluated = x
            leaf.noisyvalue = self.BBox.f_noised(x)
            existed = True
        leaf.update_path(leaf.noisyvalue, alpha, nu, k)
        return leaf.evaluated, leaf.noisyvalue, existed
