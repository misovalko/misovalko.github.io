import Target
import random
import math
import OO
import pylab as pl
import numpy as np
import pickle
import Test
import os
import sys

__author__ = 'jb-inria'

if len(sys.argv) > 1 and os.path.isdir(sys.argv[1]):
    DIR = sys.argv[1] + "/"
else:
    print 'Please provide an existing output directory as argument'
    exit()

MONTE_CARLO = 20
HORIZON = 2000
RHOMAX = 20
SAVE = True
NOISE_LVL = 0.1
VERBOSE = True
UPDATE_ALPHA = False
COMPUTE = True

STEPS = min(HORIZON, 10000)

alpha_ = math.log(HORIZON) * (NOISE_LVL ** 2)
NU_ = 1.


if VERBOSE:
    print MONTE_CARLO*RHOMAX*HORIZON/STEPS


def std_box(fmax, f_):
    box = Target.Box(fmax, f_)
    box.std_noise(NOISE_LVL)
    box.std_part()
    return box


double_sine = Target.DoubleSine(0.3, 0.8, 0.5)
BBox = std_box(double_sine.fmax, double_sine.f)
# BBox = std_box(1., lambda t: t)

if not COMPUTE:
    Test.show(MONTE_CARLO, DIR, double_sine.f)
    exit()


def get_regret_hoo(rho_, alpha__):
    y = [0. for w in range(HORIZON)]
    tree = OO.Tree(BBox.support, None, 0, [rho_], BBox)
    summ = 0.
    for j in range(HORIZON):
        if VERBOSE and not j % STEPS:
            print (j + z*HORIZON + i*RHOMAX*HORIZON)/STEPS, MONTE_CARLO*RHOMAX*HORIZON/STEPS
        if UPDATE_ALPHA and alpha__ < math.log(j+1) * (NOISE_LVL ** 2):
            alpha__ += 1
            tree.update_all(alpha__, NU_)
        x, _, _ = tree.sample(alpha__, NU_, 0)
        summ += BBox.fmax - BBox.f_mean(x)
        y[j] = summ/(j+1)
    return y, alpha__


data = [None for w in range(MONTE_CARLO)]
y = [[0 for j in range(HORIZON)] for w in range(RHOMAX)]
for i in range(MONTE_CARLO):
    for z in range(RHOMAX):
        regret, alpha_ = get_regret_hoo(float(z)/float(RHOMAX-1), alpha_)
        for j in range(HORIZON):
            y[z][j] += regret[j]
    if SAVE:
        with open(DIR+"data"+str(i), 'wb') as f:
            pickle.dump(y, f)
        y = [[0. for w in range(HORIZON)] for w in range(RHOMAX)]


if VERBOSE:
    print "POO !"

rhos = [u/float(RHOMAX - 1) for u in range(RHOMAX)]
ypoo = [[0. for j in range(HORIZON)] for w in range(MONTE_CARLO)]
# sharedcompt = [[] for w in range(MONTE_CARLO)]
for i in range(MONTE_CARLO):
    tree = OO.Tree(BBox.support, None, 0, rhos, BBox)
    compt = 0
    summ = [0.] * len(rhos)
    empp = [0.] * len(rhos)
    nsam = [0] * len(rhos)
    while compt < HORIZON:
        if VERBOSE and not compt % STEPS:
            print (compt + i*HORIZON)/STEPS, MONTE_CARLO*HORIZON/STEPS, "POO"
        # compt___ = 0
        for k in range(len(rhos)):
            x, noised, existed = tree.sample(alpha_, NU_, k)
            summ[k] += BBox.fmax - BBox.f_mean(x)
            empp[k] += noised
            compt += existed
            nsam[k] += 1
            # compt___ += existed
            if existed and compt <= HORIZON:
                best_k = max(range(len(rhos)), key=lambda x: (-float("inf") if nsam[k] == 0 else empp[x]/nsam[k]))
                ypoo[i][compt-1] = 1 if nsam[best_k] == 0 else summ[best_k]/float(nsam[best_k])
        # sharedcompt[i].append(compt___)

if SAVE:
    with open(DIR+"dataPOO", 'wb') as f:
        pickle.dump(ypoo, f)
    # with open(DIR+"shared", 'wb') as f:
    #     pickle.dump(sharedcompt, f)
    Test.show(MONTE_CARLO, DIR, double_sine.f)

