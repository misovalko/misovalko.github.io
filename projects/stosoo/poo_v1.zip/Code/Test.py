import pylab as pl
import numpy as np
import Target
import pickle
import math
from operator import add

__author__ = 'jb-inira'

pl.rcParams['ps.useafm'] = True
pl.rcParams['pdf.use14corefonts'] = True
pl.rcParams['text.usetex'] = True
pl.rcParams['axes.labelsize'] = 30
pl.rcParams['xtick.labelsize'] = 25
pl.rcParams['ytick.labelsize'] = 25
pl.rcParams['legend.fontsize'] = 25


def show(montecarlo, dir_, opt_func):
    data = range(montecarlo)

    for i in range(montecarlo):
        with open(dir_+"data"+str(i), 'rb') as f:
            data[i] = pickle.load(f)
        print str(i)+"/"+str(montecarlo)


    horizon = len(data[0][0])
    rhomax = len(data[0])
    rho_tocompare = [int(rhomax*w/4.) for w in range(4)]
    style = [[5,5], [1,3], [5,3,1,3], [5,2,5,2,5,10]]

    with open(dir_+"dataPOO", 'rb') as f:
        ypoo = pickle.load(f)

    meanpoo = [sum([ypoo[w][j]/montecarlo for w in range(montecarlo)]) for j in range(horizon)]

    sumone = [[sum([data[i][z][j] for i in range(montecarlo)]) for j in range(horizon)] for z in range(rhomax)]
    mean = [[v/float(montecarlo) for v in u] for u in sumone]
    sumtwo = [[sum([(data[i][z][j]-mean[z][j])**2 for i in range(montecarlo)]) for j in range(horizon)] for z in range(rhomax)]
    sdmoment = [[v/float(montecarlo) for v in u] for u in sumtwo]
    stdv = [[math.sqrt(sdmoment[z][j]/float(montecarlo-1)) for j in range(horizon)] for z in range(rhomax)]

    x = [i/1000. for i in range(1000)]
    y = map(opt_func, x)
    pl.plot(np.array(x), np.array(y))
    pl.show()


    X = np.array(range(horizon))

    for i in range(len(rho_tocompare)):
        w = rho_tocompare[i]
        label__ = r"$\mathtt{HOO}, \rho = "+str(float(w)/rhomax)+"$"
        pl.plot(X, np.array(mean[w]), label=label__, dashes=style[i])
    pl.plot(X, np.array(meanpoo), label=r"$\mathtt{POO}$")
    pl.legend()
    pl.xlabel("number of evaluations")
    pl.ylabel("simple regret")
    pl.show()

    X = np.array(map(math.log, range(horizon)[1:]))
    for i in range(len(rho_tocompare)):
        w = rho_tocompare[i]
        label__ = r"$\mathtt{HOO}, \rho = "+str(float(w)/rhomax)+"$"
        pl.plot(X, np.array(map(math.log, mean[w][1:])), label=label__, dashes=style[i])
    YPOO = np.array(map(math.log, meanpoo[1:]))
    pl.plot(X, YPOO, label=r"$\mathtt{POO}$")
    pl.legend(loc=3)
    pl.xlabel("number of evaluation (log-scaled)")
    pl.ylabel("simple regret (log-scaled)")
    pl.show()

    X = np.array([float(z)/float(rhomax-1) for z in range(rhomax)])
    Y = np.array([mean[z][horizon-1] for z in range(rhomax)])
    Z1 = np.array([mean[z][horizon-1]+2*stdv[z][horizon-1] for z in range(rhomax)])
    Z2 = np.array([mean[z][horizon-1]-2*stdv[z][horizon-1] for z in range(rhomax)])
    pl.plot(X, Y)
    pl.plot(X, Z2, color="green")
    pl.plot(X, Z1, color="green")
    pl.xlabel(r"$\rho$")
    pl.ylabel(r"simple regret after $10^5$ evaluations")
    pl.show()

    X = np.array([float(z)/float(rhomax-1) for z in range(rhomax)])
    Z = np.array([mean[z][horizon-1] for z in range(rhomax)])
    E = np.array([2*stdv[z][horizon-1] for z in range(rhomax)])
    pl.errorbar(X, Y, yerr=E, color="black", errorevery=3)
    pl.xlabel(r"$\rho$")
    pl.ylabel(r"simple regret after $5000$ evaluations")
    pl.show()

#
# ds = Target.DoubleSine(0.25, 0.707, 0.5)
# X = np.array([x/10000. for x in range(10000)])
# Y = np. array([ds.f(x/10000.) for x in range(10000)])
# Y1 = np. array([-math.sqrt(math.fabs(x/5000.-1.)) for x in range(10000)])
# Y2 = np. array([-math.pow(x/5000.-1., 2) for x in range(10000)])
# pl.plot(X, Y, color="black")
# pl.plot(X, Y)
# pl.plot(X, Y1)
# pl.plot(X, Y2)
# pl.xlabel("$x$")
# pl.ylabel("$f(x)$")
# pl.show()

