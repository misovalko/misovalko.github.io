import math
import random
import pylab as pl
import numpy as np
import math

__author__ = 'jb-inira'


def mysin(x):
    if x - math.floor(x) < 0.5:
        return 1.
    else:
        return 0.


def mysin2(x):
    return (math.sin(x*2*math.pi)+1)/2.


def std_center(s):
    a, b = s
    return (a+b)/2.


def std_rpoint(s):
    a, b = s
    return a + (b-a)*random.random()


def std_split(s):
    a, b = s
    m = (a+b)/2.
    return [(a, m), (m, b)]


def std_noise(x, noise_lvl):
    return x + noise_lvl*random.random()


def noisyy(x):
    if x > random.random():
        return 1.
    else:
        return 0.


class DoubleSine:
    def __init__(self, rho1, rho2, tmax):
        self.ep1 = -math.log(rho1, 2)
        self.ep2 = -math.log(rho2, 2)
        self.tmax = tmax
        self.fmax = 0.

    def f(self, x):
        u = 2*math.fabs(x-self.tmax)
        if u == 0:
            return 0.
        else:
            envelope_width = math.pow(u, self.ep2)-math.pow(u, self.ep1)
            return mysin2(math.log(u, 2)/2.)*envelope_width - math.pow(u, self.ep2)

    def fmax(self):
        return self.fmax


class Box:
    def __init__(self, fmax, f):
        self.support = None
        self.fmax = fmax
        self.center = None
        self.rpoint = None
        self.split = None
        self.f_noised = None
        self.f_mean = f

    def std_part(self):
        self.center = std_center
        self.rpoint = std_rpoint
        self.split = std_split
        self.support = (0., 1.)

    def std_noise(self, noise_lvl):
        self.f_noised = lambda x: std_noise(self.f_mean(x), noise_lvl)
        # self.f_noised = noisyy

    def plot(self):
        x = np.array([k/10000. for k in range(10000)])
        y = np.array([self.f_mean(k/10000.) for k in range(100000)])
        pl.plot(x, y)
        pl.show()


