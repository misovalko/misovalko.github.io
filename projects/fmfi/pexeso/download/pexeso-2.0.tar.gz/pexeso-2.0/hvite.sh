#!/bin/sh
MODELDIR=modely
CONFIGDIR=config
./viterbi -d $MODELDIR -w $MODELDIR/speech.lat -C $CONFIGDIR/pexeso.conf -m $MODELDIR/speech.word $MODELDIR/hmm.list 


