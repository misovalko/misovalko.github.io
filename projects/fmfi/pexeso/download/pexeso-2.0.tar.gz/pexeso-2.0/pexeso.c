#define FIFONAME "pexeso.fifo"
#define PEXESOSETPATH "sets/"
#define N 50
#define NIMAGES N*N/2
#define BUFLEN 256
#include <unistd.h>
#include <gtk/gtk.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>


int n; 
int nimages() { return n*n/2; }

struct POLICKO {gint i, j, pex, stav; GtkWidget *image; GtkWidget *event_box; }; 
//stav: 0 - rub; 1 - lice; 2 - uz tam nie je 
struct HRAC {gint pocet; gchar meno[50]; };
gchar setname[BUFLEN];
gboolean recognition;
typedef struct POLICKO * PP;
struct POLICKO tabulka[N+2][N+2]; 
PP tab[N+2][N+2];
struct HRAC h[2];

gint hvitefifo; 
GtkWidget *HlavneOkno;
GtkWidget *table1, *body[2];
GdkPixbuf *nova, *koniec, *player, *turn, *blank, *deck, *ikona, *selected;
GdkPixbuf *pex[NIMAGES], *imstlpec[N], *imriadok[N];
guint oznaceny_stlpec, oznaceny_riadok, otoceny_riadok, otoceny_stlpec, potocenych, akthrac=1;

void close_application( GtkWidget *widget, gpointer   data ) {
  gtk_main_quit ();
}

void zmenhraca() {
  gtk_image_set_from_pixbuf(GTK_IMAGE(tab[akthrac*(n+1)][0]->image),blank);      
  gtk_widget_queue_draw(tab[akthrac*(n+1)][0]->image);
  akthrac=1-akthrac; 
  gtk_image_set_from_pixbuf(GTK_IMAGE(tab[akthrac*(n+1)][0]->image),player);      
  gtk_widget_queue_draw(tab[akthrac*(n+1)][0]->image);

}

void okraj_reset(guint s,guint r) {
  GdkPixbuf *pb; 
  if (!s) pb=imriadok[r-1];
  if (!r) pb=imstlpec[s-1];
  gtk_image_set_from_pixbuf(GTK_IMAGE(tab[s][r]->image),pb);      
  gtk_widget_queue_draw(tab[s][r]->image);
}

void oznac(guint s, guint r) {
  gtk_image_set_from_pixbuf(GTK_IMAGE(tab[s][r]->image),selected);   
  gtk_widget_queue_draw(tab[s][r]->image);

}


void zmenstav(guint s, guint r, guint stav) {

  if (stav==0) gtk_image_set_from_pixbuf(GTK_IMAGE(tab[s][r]->image),deck);   
  if (stav==1) gtk_image_set_from_pixbuf(GTK_IMAGE(tab[s][r]->image),pex[tab[s][r]->pex]);   
  if (stav==2) gtk_image_set_from_pixbuf(GTK_IMAGE(tab[s][r]->image),blank);   

  tab[s][r]->stav=stav;
  gtk_widget_queue_draw(tab[s][r]->image);

}


static gboolean g_oznac_stlpec(GtkWidget *widget,  GdkEventButton  *event, gint stlpec){
  if (potocenych >= 2) return FALSE;
  if (oznaceny_stlpec!=-1) { 
    okraj_reset(oznaceny_stlpec,0);
    oznaceny_stlpec=-1;
  }

  oznac((gint) stlpec,0);
  oznaceny_stlpec=(gint)stlpec;
  g_print("Marked column: %d\n",oznaceny_stlpec); 
  return FALSE;
}

static gboolean g_oznac_riadok(GtkWidget *widget,  GdkEventButton  *event, gint riadok){
  if (potocenych >= 2) return FALSE;
  if (oznaceny_riadok!=-1) { 
    okraj_reset(0,oznaceny_riadok); 
    oznaceny_riadok=-1;
  }
  oznac(0,riadok);
  oznaceny_riadok=(gint)riadok;
  g_print("Marked row: %d\n",oznaceny_riadok); 
  return FALSE;
}

void pockaj(void) {
  gdk_window_process_all_updates();
  sleep(1);
}


void ukaz_body(void) {
  guint i;
  gchar bodytext[BUFLEN];
  for(i=0;i<2;i++) { 
    g_snprintf(bodytext,BUFLEN,"<span weight=\"bold\" size=\"xx-large\">%d</span>",h[i].pocet);
    gtk_label_set_markup(GTK_LABEL(tab[i*(n+1)][n+1]->image),bodytext);
  }

}


static gboolean g_hram(GtkWidget *widget,  GdkEventButton  *event, gpointer p){
  g_print("2 cards was turned yet.\n");
  if (potocenych==2) {
    if (tab[oznaceny_stlpec][oznaceny_riadok]->pex == tab[otoceny_stlpec][otoceny_riadok]->pex) {
      h[akthrac].pocet++;
      ukaz_body();
//      system("./prehraj.sh "ZVUKY"/potlesk.wav"); 
      pockaj();
      zmenstav(oznaceny_stlpec, oznaceny_riadok,2);
      zmenstav(otoceny_stlpec, otoceny_riadok,2); 
    }
    else {
      pockaj();
      zmenstav(oznaceny_stlpec, oznaceny_riadok, 0);
      zmenstav(otoceny_stlpec, otoceny_riadok,0); 
      zmenhraca();      
    }
    potocenych=0; 

  } 
  return FALSE;
}

static gboolean g_nova(GtkWidget *widget,  GdkEventButton  *event, gpointer p){
  guint r,s,x,i;
  zmenhraca();
  oznaceny_stlpec=oznaceny_riadok=otoceny_riadok=otoceny_stlpec=-1;
  g_print("Starting new game...\n");
  potocenych=0;
  h[0].pocet=0;
  h[1].pocet=0;
  if (g_random_boolean()) zmenhraca();
  ukaz_body();
  for(r=1;r<=n;r++) {
    okraj_reset(r,0);
    okraj_reset(0,r);
  }

  for(r=1;r<=n;r++) 
    for(s=1;s<=n;s++) {
      zmenstav(r,s,0);
      tab[s][r]->pex=-1;
    }


  for (x=0;x<nimages();x++) {
    for(i=0;i<2;i++) {
      do {
        s = g_random_int_range(1,n+1); 
        r = g_random_int_range(1,n+1); 
      }	 while (tab[s][r]->pex!=-1); 
      tab[s][r]->pex=x; 
      g_print("Card %d was assigned to position [%d,%d].\n",x,s,r); 
    }	     
  }  
  return FALSE;
}


static gboolean g_otoc(GtkWidget *widget,  GdkEventButton  *event,  gpointer p){
  g_print("Turning cards...\n"); 
  if ((potocenych < 2) && 
      (oznaceny_riadok!=-1) && 
      (oznaceny_stlpec!=-1) && 
      (tab[oznaceny_stlpec][oznaceny_riadok]->stav==0)) {

    zmenstav(oznaceny_stlpec,oznaceny_riadok,1); 
    potocenych++;

    if (potocenych==1) { 
      otoceny_stlpec=oznaceny_stlpec;
      otoceny_riadok=oznaceny_riadok;

    }
    okraj_reset(0,oznaceny_riadok);
    okraj_reset(oznaceny_stlpec,0);

    if (potocenych==2)  g_hram(NULL,NULL,NULL);
    oznaceny_riadok=-1;
    oznaceny_stlpec=-1;

  }


  return FALSE;
}


void rozpoznaj(char *slovo) {
  g_print("Recognized: %s\n",slovo);
  guint x; 
  gchar model[BUFLEN];

  for (x=1;x<=n;x++) {
    g_snprintf(model,BUFLEN,"R%d",x);
    if (g_strrstr(model,slovo)) g_oznac_riadok(NULL,NULL,x);
    g_snprintf(model,BUFLEN,"C%d",x);
    if (g_strrstr(model,slovo)) g_oznac_stlpec(NULL,NULL,x);
  }
  
  //if (g_strrstr(slovo,"KONIEC"))  close_application(NULL,NULL);
  if (!g_ascii_strcasecmp("TURN", slovo)) g_otoc(NULL,NULL,NULL);
}

void nacitaj_obrazky(void) {
  guint i;
  GError *error=NULL;
  gchar path[BUFLEN];

  g_print("Reading auxilary images...\n");
  deck=gdk_pixbuf_new_from_file (g_strconcat(setname,"deck.png",NULL), &error);
  selected=gdk_pixbuf_new_from_file (g_strconcat(setname,"selected.png",NULL), &error);  
  blank=gdk_pixbuf_new_from_file (g_strconcat(setname,"blank.png",NULL), &error);  
  turn=gdk_pixbuf_new_from_file (g_strconcat(setname,"turn.png", NULL), &error);  
  player=gdk_pixbuf_new_from_file (g_strconcat(setname,"player.png",NULL), &error);  
  koniec=gdk_pixbuf_new_from_file (g_strconcat(setname,"end.png",NULL), &error);  
  nova=gdk_pixbuf_new_from_file (g_strconcat(setname,"new.png",NULL), &error);  
  ikona=gdk_pixbuf_new_from_file (g_strconcat("ikona.png",NULL), &error);  


  g_print("Reading cards...\n");
  for(i=0;i<n;i++) {
    g_snprintf(path,BUFLEN,"%sC%d.png",setname,i+1);
    g_print("Reading image for %d. column from %s...\n",i+1,path);
    imstlpec[i]=gdk_pixbuf_new_from_file(path,&error); 
    g_snprintf(path,BUFLEN,"%sR%d.png",setname,i+1);
    g_print("Reading image for %d. row from %s...\n",i+1,path);
    imriadok[i]=gdk_pixbuf_new_from_file(path,&error); 

  }
}

void nacitaj_pexesa(void) {
  guint x;
  GError *error=NULL;
  char path[BUFLEN];

  for (x=0;x<nimages();x++) {
    g_snprintf(path,BUFLEN,"%s%d.png",setname,x);
    error=NULL;
    pex[x]=gdk_pixbuf_new_from_file (path, &error);   
    g_print("Pexeso %d nacitane z %s.\n",x,path);
  }
}
void prirad_eventy_tabulke (void) {
  guint r,s;
  for(s=0;s<=n+1;s++) {
    for(r=0;r<=n+1;r++) {
      tab[s][r]=&(tabulka[s][r]);
      tab[s][r]->event_box = gtk_event_box_new();
      if ((s>0) && (r>0) && (s<=n) && (r<=n)) {
        tab[s][r]->image =  GTK_WIDGET(gtk_image_new_from_pixbuf(deck));   
        tab[s][r]->pex=-1;	
        tab[s][r]->stav=0;
        g_signal_connect ((gpointer) tab[s][r]->event_box, "button_press_event",
            G_CALLBACK (g_oznac_stlpec),
            (gpointer) s);
        g_signal_connect ((gpointer) tab[s][r]->event_box, "button_press_event",
            G_CALLBACK (g_oznac_riadok),
            (gpointer) r);
      }
      else if ((r==0) && (s!=0) && (s<=n)) {
        tab[s][r]->image =  GTK_WIDGET(gtk_image_new_from_pixbuf(imstlpec[s-1]));  
        g_signal_connect ((gpointer) tab[s][r]->event_box, "button_press_event",
            G_CALLBACK (g_oznac_stlpec),
            (gpointer) s);
      }
      else if ((s==0) && (r!=0) && (r<=n)) {
        tab[s][r]->image =  GTK_WIDGET(gtk_image_new_from_pixbuf(imriadok[r-1]));  
        g_signal_connect ((gpointer) tab[s][r]->event_box, "button_press_event",
            G_CALLBACK (g_oznac_riadok),
            (gpointer) r);
      }     
      else if (r==n+1)  {
        tab[s][r]->image =  gtk_label_new (NULL);

      }
      else if ((r==1) && (s==n+1)) {
        tab[s][r]->image =  GTK_WIDGET(gtk_image_new_from_pixbuf(turn));       
        g_signal_connect ((gpointer) tab[s][r]->event_box, "button_press_event",
            G_CALLBACK (g_otoc),
            NULL);
      }
      else if ((r==n-1) && (s==n+1)) {
        tab[s][r]->image =  GTK_WIDGET(gtk_image_new_from_pixbuf(nova));       
        g_signal_connect ((gpointer) tab[s][r]->event_box, "button_press_event",
            G_CALLBACK (g_nova), 
            NULL);
      }
      else if ((r==n) && (s==n+1)) {
        tab[s][r]->image =  GTK_WIDGET(gtk_image_new_from_pixbuf(koniec));       
        g_signal_connect ((gpointer) tab[s][r]->event_box, "button_press_event",
            G_CALLBACK (close_application), 
            NULL);
      }
      else {
        tab[s][r]->image =  GTK_WIDGET(gtk_image_new_from_pixbuf(blank));   
      }

      gtk_widget_show (tab[s][r]->image); 
      gtk_container_add(GTK_CONTAINER(tab[s][r]->event_box),tab[s][r]->image);
      gtk_widget_show (tab[s][r]->event_box); 
      gtk_table_attach (GTK_TABLE (table1), tab[s][r]->event_box, s, s+1, r, r+1, 
          (GtkAttachOptions) (GTK_FILL), (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);
    }
  }
}  




GtkWidget* create_HlavneOkno (void) {

  HlavneOkno = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (HlavneOkno), "PEXESO - Pekelne Sa Sustred!");
  gtk_window_set_position (GTK_WINDOW (HlavneOkno), GTK_WIN_POS_CENTER);

  g_signal_connect (G_OBJECT (HlavneOkno), "destroy", G_CALLBACK (close_application), NULL);

  table1 = gtk_table_new (n + 2 , n + 2, FALSE);
  gtk_widget_show (table1);
  gtk_container_add (GTK_CONTAINER (HlavneOkno), table1);

  nacitaj_obrazky();
  prirad_eventy_tabulke();
  nacitaj_pexesa();
  gtk_window_set_icon (GTK_WINDOW (HlavneOkno), ikona);

  return HlavneOkno;
}

gboolean timer(gpointer data) {
  char buffer[BUFLEN];
  buffer[0] = 0;
  int ret = read(hvitefifo, buffer, BUFLEN-1);
  if(ret>0){
    buffer[ret]=0;
    rozpoznaj(buffer);
    buffer[0]=0;
  }
  return TRUE;
}


int main (int argc, char *argv[])
{
  FILE *subor; 
  g_snprintf(setname,BUFLEN,"%s%s/",PEXESOSETPATH, (argc>=2) ? (char *) argv[1] : "default");
  g_print("Choosen set: %s\n",setname);
  subor = fopen(g_strconcat(setname,"N",NULL),"rt"); 
  if (!subor) {
    g_print(g_strconcat("Set \"", setname, "\" not found.\n",NULL));
    return -1;
  }

  fscanf(subor,"%d",&n);
  fclose(subor);

  subor = fopen(g_strconcat(setname,"speech.lat",NULL),"rt"); 
  recognition = (gboolean)(subor);
  if (subor) fclose(subor); 
  
  
  if (n%2) { g_print("N must be even"); return -2; }
  
  g_print("Setting board to size %dx%d\n",n,n);

  
  gint pid=fork();
  if (pid) {

    if (recognition)     g_print("Speech recognition launched in background - process id: %d\n",pid);   
    else g_print("Set without speech recognition.\n");

    GtkWidget *HlavneOkno;
    gtk_init (&argc, &argv);

    HlavneOkno = create_HlavneOkno ();
    g_nova(NULL,NULL,NULL);   
    gtk_widget_show (HlavneOkno);
    hvitefifo = open(FIFONAME, O_RDONLY | O_NONBLOCK );
    static guint Timer;
    Timer = gtk_timeout_add(100, timer, NULL);  
    gtk_main ();
    gtk_timeout_remove(Timer);
    close(hvitefifo);
    if (recognition) {
      g_print("Stopping speech recognition...\n");
      kill(pid,9);  
    }
  }
  else {
    
    freopen("/dev/null",".",stdout);
    if (recognition) {
      execl("./viterbi","viterbi",
          "-d",setname,
          "-w",g_strconcat(setname,"speech.lat",NULL),
          "-C","config/pexeso.conf",
          "-m",g_strconcat(setname,"speech.word",NULL),
          g_strconcat(setname,"hmm.list",NULL),
          0);
    }
  }
  return 0;
}

