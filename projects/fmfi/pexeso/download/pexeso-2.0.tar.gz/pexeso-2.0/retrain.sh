#!/bin/sh
./dotrenuj.sh biely 
./dotrenuj.sh zlty 
./dotrenuj.sh fialovy 
./dotrenuj.sh oranzovy 
./dotrenuj.sh stol
./dotrenuj.sh kruzok 
./dotrenuj.sh domcek 
./dotrenuj.sh tucniak 
./dotrenuj.sh otoc 
./dotrenuj.sh koniec
