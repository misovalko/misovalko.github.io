#!/bin/sh
./trenuj.sh biely 
./trenuj.sh zlty 
./trenuj.sh fialovy 
./trenuj.sh oranzovy 
./trenuj.sh stol
./trenuj.sh kruzok 
./trenuj.sh domcek 
./trenuj.sh tucniak 
./trenuj.sh otoc 
./trenuj.sh koniec
