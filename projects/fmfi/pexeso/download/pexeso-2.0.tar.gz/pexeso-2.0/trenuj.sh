#!/bin/sh

INIPROTO=config/proto.hmm
HRESTCONF=config/mfcc.conf
MODELDIR=modely
SAMPLEDIR=vzorky
LABEL=Speech

find $PWD/$SAMPLEDIR/$1 -name "$1*.wav" > $MODELDIR/$1.wordlist
echo Running HInit...
HInit -l $LABEL -S $MODELDIR/$1.wordlist -C $HRESTCONF -M $MODELDIR -o $1 $INIPROTO
echo Running HRest...
HRest -l $LABEL -M $MODELDIR -H  $INIPROTO -v 0.00001 -e 0.00001 -S $MODELDIR/$1.wordlist -C $HRESTCONF -i 100 $MODELDIR/$1
echo Done.
