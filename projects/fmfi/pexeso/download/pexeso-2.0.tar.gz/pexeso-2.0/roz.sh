#!/bin/sh

SETDIR=sets/default

./viterbi  -d $SETDIR  -w $SETDIR/speech.lat -C config/pexeso.conf -m $SETDIR/speech.word $SETDIR/hmm.list 
