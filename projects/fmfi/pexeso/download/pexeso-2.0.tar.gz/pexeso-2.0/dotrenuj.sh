#!/bin/sh

INIPROTO=config/proto.hmm
HRESTCONF=config/mfcc.conf
MODELDIR=modely
SAMPLEDIR=vzorky
LABEL=Speech

HRest -l $LABEL -M $MODELDIR -H  $INIPROTO -v 0.00001 -e 0.00001 -S $MODELDIR/$1.wordlist -C $HRESTCONF -i 100 $MODELDIR/$1
