//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#define TAU 0.608

#include "CordicMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

#include <algorithm.h>

using namespace std;

long double getTau(int t) {
  int i;
  long double output=1;
  for(i=0;i<=t;i++) output*=1/sqrtl(1+powl(2,-2*i));
  return output;
}


void __fastcall TForm1::Button1Click(TObject *Sender) {

  Button1->Enabled=false;


  long double angle,vx,vy,p,sx,sy,beta;

  try  {
     beta = StrToFloat(Input->Text);
  }
  catch(EConvertError *e) {
      Sb->SimpleText="Zadan� hodnota nie je v ��slo";
      Button1->Enabled=true;
      return;
  }

  if (!Typ->ItemIndex) beta=M_PI*(long double)beta/180;

  if (beta<-M_PI/2 || beta>M_PI/2) {
     Sb->SimpleText="Zadan� hodnota nie je v rozmedz� (-Pi/2,Pi/2) !";
     Button1->Enabled=true;
     return;
  }

  long double oldbeta = beta;

  Cos->Text="Pocitam...";
  Sin->Text="Pocitam...";
  Kcos->Text="Pocitam...";
  Ksin->Text="Pocitam...";
  Sb->SimpleText="Pocitam...";

  int sigma;
  int t=27,j;
  vx=getTau(2*t-1);
  vy=0;

  Memo1->Lines->Clear();
  Memo2->Lines->Clear();

  int s1=Img->Width/2;
  int s2=Img->Height/2;


  for(int i=0;i<2*t;i++) {
    Memo1->Lines->Add(IntToStr(i) + ":" +  FloatToStr(vx));
    Memo2->Lines->Add(IntToStr(i) + ":" +  FloatToStr(vy));

    Img->Canvas->Brush->Color = clBtnFace;
    Img->Canvas->Pen->Color = clBlack;
    Img->Canvas->Ellipse(0,0,2*s1,2*s2);
    Img->Canvas->MoveTo(0,s2);
    Img->Canvas->LineTo(2*s1,s2);
    Img->Canvas->MoveTo(s1,0);
    Img->Canvas->LineTo(s1,2*s2);
    Img->Canvas->Pen->Color=clGreen;
    Img->Canvas->MoveTo(s1,s2);
    Img->Canvas->LineTo(s1*(1+cos(oldbeta)),s2*(1-sin(oldbeta)));
    Img->Canvas->Pen->Color=clRed;
    Img->Canvas->MoveTo(s1,s2);
    Img->Canvas->LineTo(s1*(1+vx),s2*(1-vy));


    for(j=0; j<Tb->Position; j++)  { Application->ProcessMessages(); }

    sigma=(beta>=0) ? 1: -1;
    p=powl(2,-i);
    sx = vx;
    sy = vy;
    vx = sx - sigma*p*sy;
    vy = sigma*p*sx + sy;
    beta = beta - sigma*atanl(p);
  }


  Cos->Text=FloatToStr(vx);
  Sin->Text=FloatToStr(vy);
  Kcos->Text=FloatToStr(cosl(oldbeta));
  Ksin->Text=FloatToStr(sinl(oldbeta));

  Sb->SimpleText="Hotovo";
  Button1->Enabled=true;

}
//---------------------------------------------------------------------------


void __fastcall TForm1::FormCreate(TObject *Sender) {

  Img->Canvas->Brush->Color=clBtnFace;
  Img->Canvas->Rectangle(-1,-1,Img->Width+1,Img->Height+1);

}
//---------------------------------------------------------------------------

