//---------------------------------------------------------------------------

#ifndef CordicMainH
#define CordicMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TEdit *Input;
        TButton *Button1;
        TStatusBar *Sb;
        TEdit *Cos;
        TEdit *Sin;
        TMemo *Memo1;
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TGroupBox *GroupBox2;
        TImage *Img;
        TGroupBox *GroupBox3;
        TStaticText *StaticText1;
        TStaticText *StaticText2;
        TEdit *Ksin;
        TEdit *Kcos;
        TGroupBox *GroupBox4;
        TGroupBox *GroupBox5;
        TRadioGroup *Typ;
        TMemo *Memo2;
        TTrackBar *Tb;
        TStaticText *StaticText3;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
